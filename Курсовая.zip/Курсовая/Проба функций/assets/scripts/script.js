$(document).ready(function() {
    // Инициализация доски
    var board = ChessBoard('board', {
        draggable: true,
        position: 'start',
        onDragStart: onDragStart,
        onDrop: onDrop,
        onSnapEnd: onSnapEnd,
    });

    $('#startBtn').on('click', board.start);

    function onDragStart(source, piece, position, orientation) {
        if (board.game.in_progress() === false) return false;
        if (piece.search('w') !== -1 && board.game.turn() === 'b') return false;
        if (piece.search('b') !== -1 && board.game.turn() === 'w') return false;
    }

    function onDrop(source, target) {
        var move = board.move({
            from: source,
            to: target,
            promotion: 'q' // всегда превращать в ферзя
        });

        removeGreySquares();

        if (move === null) return 'snapback';

        updateStatus();
    }

    function onSnapEnd() {
        board.position(board.fen());
    }

    function updateStatus() {
        var status = '';
        var moveColor = 'Белые';

        if (board.game.turn() === 'b') {
            moveColor = 'Черные';
        }

        if (board.game.in_check()) {
            status += moveColor + ' в шаху. ';
        }

        if (board.game.in_checkmate()) {
            status = 'Мат! ' + moveColor + ' одерживает победу!';
        }

        $('#status').html(status);
        $('#fen').html(board.fen());
    }

    function removeGreySquares() {
        $('#board .square-55d63').css('background', '');
    }

    // Формы входа и регистрации
    $('#loginForm').on('submit', function(event) {
        event.preventDefault();
        // Здесь должен быть код для проверки данных пользователя
        alert('Вход выполнен!');
    });

    $('#registerForm').on('submit', function(event) {
        event.preventDefault();
        // Здесь должен быть код для регистрации нового пользователя
        alert('Регистрация успешна!');
    });
});