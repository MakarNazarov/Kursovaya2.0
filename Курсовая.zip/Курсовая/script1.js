document.getElementById('quizForm').onsubmit = function(e) {
    e.preventDefault();
    let score = 0;
    const answers = {
        q1: "64",
        // добавьте остальные правильные ответы
    };
    for (const [key, value] of Object.entries(answers)) {
        const selectedAnswer = document.querySelector(input[name="${key}"] + checked);
        if (selectedAnswer && selectedAnswer.value === value) {
            score++;
        }
    }
    alert("Вы набрали" + score + "правильных ответов!");
};