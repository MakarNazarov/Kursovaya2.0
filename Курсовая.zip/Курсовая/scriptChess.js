function openModal(modalName) {
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modalTitle');
    const modalText = document.getElementById('modalText');
    switch (modalName) {
        case 'openingsModal':
            modalTitle.innerText = 'Открытия';
            modalText.innerText = 'Информационные технологии помогают шахматистам изучать и анализировать открытия...';
            break;
        case 'readingModal':
            modalTitle.innerText = 'Чтение позиций';
            modalText.innerText = 'Современные шахматные программы визуализируют позиции...';
            break;
        case 'timeManagementModal':
            modalTitle.innerText = 'Управление временем';
            modalText.innerText = 'Использование шахматных приложений помогает отслеживать и управлять временем...';
            break;
        case 'endgameModal':
            modalTitle.innerText = 'Концовки';
            modalText.innerText = 'Информационные технологии позволяют анализировать различные окончания...';
            break;
        default:
            modalTitle.innerText = 'Ошибка';
            modalText.innerText = 'Неизвестная ошибка.';
    }
    modal.style.display = "block";
}
function closeModal() {
    document.getElementById('modal').style.display = "none";
}